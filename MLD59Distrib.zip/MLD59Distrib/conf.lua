function love.conf(t)

	t.window.width = 800
	t.window.height = 640
	t.title = "Mini LD - 59"

end